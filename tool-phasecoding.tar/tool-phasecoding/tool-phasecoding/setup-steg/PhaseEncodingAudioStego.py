import os.path
import numpy as np
from scipy.io import wavfile
from AudioStegnographyAlgorithm import AudioStego

class PhaseEncodingAudioStego(AudioStego):
    def encodeAudio(self, audioLocation, stringToEncode) -> str:
        










        if blocks.shape == (blockNumber, blockLength):
            print("Thanh cong chia_segment")
        else:
            print("That bai chia_segment")
        blocks = np.fft.fft(blocks)


        if blocks.size > 0 and np.iscomplexobj(blocks):
            print("Thanh cong DFT_code")
        else:
            print("That bai DFT_code")
       




        if phaseDiffs.shape[0] == blockNumber - 1 and phaseDiffs.shape[1] == blockLength:
            print("Thanh cong diff_phase")
        else:
            print("That bai diff_phase")
        





        if np.any(phases[0, blockMid - textLength: blockMid] != 0):
            print("Thanh cong embed_phase")
        else:
            print("That bai embed_phase")
        for i in range(1, len(phases)):
            phases[i] = phases[i - 1] + phaseDiffs[i - 1]
        blocks = (magnitudes * np.exp(1j * phases))
        blocks = np.fft.ifft(blocks).real
        self.audioData[0] = blocks.ravel().astype(np.int16)
        return self.saveToLocation(self.audioData.T, audioLocation)
    
    def decodeAudio(self, audioLocation) -> str:
        



        if len(self.audioData.shape) == 1:
            secret = self.audioData[:blockLength]
        else:
            secret = self.audioData[:blockLength, 0]
        secretPhases = np.angle(np.fft.fft(secret))[blockMid - textLength:blockMid]
        secretInBinary = (secretPhases < 0).astype(np.int8)
        secretInIntCode = secretInBinary.reshape((-1, 8)).dot(1 << np.arange(8 - 1, -1, -1))
        decoded_message = "".join(np.char.mod("%c", secretInIntCode)).replace("~", "")
        if decoded_message:
            print("Thanh cong decode_code")
        else:
            print("That bai decode_code")
        with open("out_put_mess.txt", "w") as f:
            f.write(decoded_message)
        print(decoded_message)
        return decoded_message

    def convertToByteArray(self, audio):
        try:
            self.rate, self.audioData = wavfile.read(audio)
        except:
            pass
        self.audioData = self.audioData.copy()

    def saveToLocation(self, audioArray, location) -> str:
        dir = os.path.dirname(location)
        output_path = dir + "/output-pc.wav"
        wavfile.write(output_path, self.rate, audioArray)
        if os.path.exists(output_path):
            print("Thanh cong output_created")
        else:
            print("That bai output_created")
        return output_path

